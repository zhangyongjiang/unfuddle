package com.sencha.gxt.desktopapp.client.property;

import com.google.gwt.user.client.ui.IsWidget;

public interface PropertyView extends IsWidget {

	void showProperty(String string);

}