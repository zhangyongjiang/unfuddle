package com.sencha.gxt.desktopapp.client.canvas;

import net.edzard.kinetic.Kinetic;
import net.edzard.kinetic.Stage;

import com.gaoshin.fbobuilder.client.model.DisplayMode;
import com.gaoshin.fbobuilder.client.model.Flayer;
import com.gaoshin.fbobuilder.client.model.Fnode;
import com.gaoshin.fbobuilder.client.model.Fstage;
import com.gaoshin.fbobuilder.client.resourcemanager.FlyerProperty;
import com.gaoshin.fbobuilder.client.resourcemanager.LayerProperty;
import com.gaoshin.fbobuilder.client.resourcemanager.NodeProperty;
import com.gaoshin.fbobuilder.client.resourcemanager.PrimeProperty;
import com.gaoshin.fbobuilder.client.resourcemanager.ResourceProperty;
import com.gaoshin.fbobuilder.client.resourcemanager.ShapeProperty;
import com.google.gwt.dom.client.Element;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.widget.core.client.ContentPanel;
import com.sencha.gxt.widget.core.client.container.HorizontalLayoutContainer;

public class CanvasViewImpl {
	private Fstage fstage;
	private ContentPanel panel;
	private HorizontalLayoutContainer container;
	private DisplayMode mode = DisplayMode.Edit;
	
	public Widget getContainer() {
		if(container == null) {
			container = new HorizontalLayoutContainer();
			container.add(getPanel());
		}
		return container;
	}
	
	public ContentPanel getPanel() {
		if(panel == null) {
			panel = new ContentPanel();
			panel.setBorders(false);
			panel.setHeaderVisible(false);
		}
		return panel;
	}
	
	public void createStage(int width, int height) {
		panel.setWidth(width);
		panel.setHeight(height);
		if(fstage == null) {
			Stage stage = Kinetic.createStage(panel.getBody(), width, height);
			setFstage(new Fstage(stage, null));
			getFstage().setMode(mode);
			getFstage().draw();
		}
		else {
			reset();
			fstage.setNodeProperty(null);
			FlyerProperty fp = fstage.getResourceProperty();
			fp.updateOrCreateDoubleProperty(FlyerProperty.NameFlyerWidth, (double)width);
			fp.updateOrCreateDoubleProperty(FlyerProperty.NameFlyerHeight, (double)height);
			fstage.getNode().setWidth(width);
			fstage.getNode().setHeight(height);
		}
	}

	public void load(FlyerProperty data) {
		loadToPanel(panel.getBody(), data);
	}

	public void loadToPanel(Element xelem, FlyerProperty data) {
		panel.setWidth(data.getWidth().intValue());
		panel.setHeight(data.getHeight().intValue());
		if(fstage == null) {
			Stage stage = Kinetic.createStage(xelem, data.getWidth().intValue(), data.getHeight().intValue());
			setFstage(new Fstage(stage, null));
			fstage.setMode(mode);
		}
		getFstage().load(data);
    }

	public FlyerProperty getData() {
		if(fstage == null)
			return null;
		else
			return getFstage().getResourceProperty();
	}

    public boolean updatePrimeProperty(NodeProperty parent, PrimeProperty rp) {
		return getFstage().updatePrimeProperty(parent, rp);
    }
    
	public void selectNode(ResourceProperty nodeProperty) {
		getFstage().selectNode(nodeProperty);
    }

	public Fstage getFstage() {
	    return fstage;
    }

	public void setFstage(Fstage fstage) {
	    this.fstage = fstage;
    }

    public void reset() {
		if(getFstage() != null)
			getFstage().reset();
    }

	public void deleteShape(ShapeProperty sp) {
		getFstage().deleteShape(sp);
    }

	public Flayer createLayer() {
	    return fstage.createLayer();
    }

	public Fnode createNewNode(Class<? extends Fnode> class1, LayerProperty lp, NodeProperty np) {
		return fstage.createNewNode(class1, lp, np);
    }

	public boolean moveDown(LayerProperty layer, NodeProperty node) {
		return fstage.moveDown(layer, node);
    }

	public boolean moveUp(LayerProperty layer, NodeProperty node) {
		return fstage.moveUp(layer, node);
    }

	public void setDisplayMode(DisplayMode mode) {
		this.mode  = mode;
		if(fstage != null)
			fstage.setMode(mode);
	}
	
	public void getImage(Stage.DataUrlTarget callback) {
		fstage.getImage(callback);
	}

	public void onFontsLoaded() {
		try {
            load(getData());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	public void onImgLoaded() {
		if(fstage != null)
			fstage.onImgLoaded();
    }
}
