package com.sencha.gxt.desktopapp.client.property;

import com.sencha.gxt.desktopapp.client.Presenter;

public interface PropertyPresenter extends Presenter {

	void showProperty(String string);

}