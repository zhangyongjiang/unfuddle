package com.sencha.gxt.desktopapp.client.canvas;

import com.gaoshin.fbobuilder.client.FlyerContext;
import com.gaoshin.fbobuilder.client.message.CopyMsg;
import com.gaoshin.fbobuilder.client.message.DeleteShapeMsg;
import com.gaoshin.fbobuilder.client.message.NewFlyerMsg;
import com.gaoshin.fbobuilder.client.message.NewFolderMsg;
import com.gaoshin.fbobuilder.client.message.NewLayerMsg;
import com.gaoshin.fbobuilder.client.message.NewNodeMsg;
import com.gaoshin.fbobuilder.client.message.NewVideoMsg;
import com.gaoshin.fbobuilder.client.message.PasteMsg;
import com.gaoshin.fbobuilder.client.message.PlayMsg;
import com.gaoshin.fbobuilder.client.message.ZoomInMsg;
import com.gaoshin.fbobuilder.client.message.ZoomOutMsg;
import com.gaoshin.fbobuilder.client.model.Fcircle;
import com.gaoshin.fbobuilder.client.model.Fellipse;
import com.gaoshin.fbobuilder.client.model.Fimage;
import com.gaoshin.fbobuilder.client.model.Fline;
import com.gaoshin.fbobuilder.client.model.Fpolygon;
import com.gaoshin.fbobuilder.client.model.Frectangle;
import com.gaoshin.fbobuilder.client.model.FregularPolygon;
import com.gaoshin.fbobuilder.client.model.Ftext;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.IsWidget;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.desktopapp.client.canvas.images.Images;
import com.sencha.gxt.desktopapp.client.persistence.FileModel.FileType;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SelectEvent.SelectHandler;
import com.sencha.gxt.widget.core.client.toolbar.SeparatorToolItem;
import com.sencha.gxt.widget.core.client.toolbar.ToolBar;

public class CanvasToolBar implements IsWidget {

	private static final String FILE_TYPE = "fileType";

	private ToolBar toolBar;
	private TextButton btnNewLine;
	private TextButton btnNewText;
	private TextButton createProgramTextButton;
	private TextButton btnNewEllipse;
	private TextButton btnNewCircle;
	private TextButton btnNewRect;
	private TextButton btnRemoveSelected;
	private TextButton zoomoutButton;
	private TextButton zoominButton;
	private TextButton layersButton;
	private SelectHandler newLineHandler;
	private SelectHandler circleSelectHandler;
	private SelectHandler rectSelectHandler;
	private SelectHandler deleteSelectHandler;
	private SelectHandler newEllipseHandler;
	private TextButton btnNewPolygon;
	private TextButton btnNewRegularPolygon;
	private SelectHandler newTextHandler;
	private SelectHandler zoominHandler;
	private SelectHandler zoomoutHandler;
	private SelectHandler newPolygonHandler;
	private SelectHandler newRegularPolygonHandler;
	private SelectHandler newImageHandler;
	private SelectHandler layersHandler;
	private TextButton btnNewFlyer;
	private TextButton btnNewVideo;
	private TextButton btnPlay;
	private TextButton btnFolder;
	private TextButton btnCopy;
	private TextButton btnPaste;
	private TextButton btnHOme;
	private SelectHandler newFlyerHandler;
	private SelectHandler newVideoHandler;
	private SelectHandler playHandler;
	private SelectHandler folderHandler;

	public Widget asWidget() {
		return getToolBar();
	}

	private SelectHandler getNewCircleHandler() {
		if (circleSelectHandler == null) {
			circleSelectHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(Fcircle.class));
				}
			};
		}
		return circleSelectHandler;
	}

	private SelectHandler getNewRectangleHandler() {
		if (rectSelectHandler == null) {
			rectSelectHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(Frectangle.class));
				}
			};
		}
		return rectSelectHandler;
	}

	private TextButton getNewCircleButton() {
		if (btnNewCircle == null) {
			btnNewCircle = new TextButton();
			btnNewCircle.setToolTip("New&nbsp;Circle");
			btnNewCircle.setIcon(Images.getImageResources().circle_32());
			btnNewCircle.addSelectHandler(getNewCircleHandler());
		}
		return btnNewCircle;
	}

	private TextButton getNewRectButton() {
		if (btnNewRect == null) {
			btnNewRect = new TextButton();
			btnNewRect.setToolTip("New&nbsp;Rectangle");
			btnNewRect.setIcon(Images.getImageResources().rectangle_32());
			btnNewRect.addSelectHandler(getNewRectangleHandler());
		}
		return btnNewRect;
	}

	private TextButton getNewEllipseButton() {
		if (btnNewEllipse == null) {
			btnNewEllipse = new TextButton();
			btnNewEllipse.setToolTip("New&nbsp;Ellipse");
			btnNewEllipse.setIcon(Images.getImageResources().ellipse_32());
			btnNewEllipse.setData(FILE_TYPE, FileType.BOOKMARK);
			btnNewEllipse.addSelectHandler(getNewEllipseHandler());
		}
		return btnNewEllipse;
	}

	private TextButton getNewImageButton() {
		if (createProgramTextButton == null) {
			createProgramTextButton = new TextButton();
			createProgramTextButton.setToolTip("New&nbsp;Image");
			createProgramTextButton.setIcon(Images.getImageResources()
			        .picture_32());
			createProgramTextButton.setData(FILE_TYPE, FileType.PROGRAM);
			createProgramTextButton.addSelectHandler(getNewImageHandler());
		}
		return createProgramTextButton;
	}

	private TextButton getNewLineButton() {
		if (btnNewLine == null) {
			btnNewLine = new TextButton();
			btnNewLine.setToolTip("New&nbsp;Line");
			btnNewLine.setIcon(Images.getImageResources().line_32());
			btnNewLine.setData(FILE_TYPE, FileType.PROGRAM);
			btnNewLine.addSelectHandler(getNewLineHandler());
		}
		return btnNewLine;
	}

	private SelectHandler getNewEllipseHandler() {
		if (newEllipseHandler == null) {
			newEllipseHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(Fellipse.class));
				}
			};
		}
		return newEllipseHandler;
	}

	private SelectHandler getNewImageHandler() {
		if (newImageHandler == null) {
			newImageHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(Fimage.class));
				}
			};
		}
		return newImageHandler;
	}

	private SelectHandler getNewLineHandler() {
		if (newLineHandler == null) {
			newLineHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(Fline.class));
				}
			};
		}
		return newLineHandler;
	}

	private TextButton getNewTextButton() {
		if (btnNewText == null) {
			btnNewText = new TextButton();
			btnNewText.setToolTip("New&nbsp;Text");
			btnNewText.setIcon(Images.getImageResources().text_icon_32());
			btnNewText.setData(FILE_TYPE, FileType.SPREADSHEET);
			btnNewText.addSelectHandler(getNewTextHandler());
		}
		return btnNewText;
	}

	private SelectHandler getNewTextHandler() {
		if (newTextHandler == null) {
			newTextHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(Ftext.class));
				}
			};
		}
		return newTextHandler;
    }

	private SelectHandler getDeleteSelectHandler() {
		if (deleteSelectHandler == null) {
			deleteSelectHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new DeleteShapeMsg());
				}
			};
		}
		return deleteSelectHandler;
	}

	private TextButton getRemoveSelectedButton() {
		if (btnRemoveSelected == null) {
			btnRemoveSelected = new TextButton();
			btnRemoveSelected.setToolTip("Remove&nbsp;Selected");
			btnRemoveSelected.setIcon(Images.getImageResources().remove_32());
			btnRemoveSelected.addSelectHandler(getDeleteSelectHandler());
		}
		return btnRemoveSelected;
	}

	private TextButton getZoominButton() {
		if (zoominButton == null) {
			zoominButton = new TextButton();
			zoominButton.setToolTip("Zoom&nbsp;In");
			zoominButton.setIcon(Images.getImageResources().zoomin_32());
			zoominButton.addSelectHandler(getZoominHandler());
		}
		return zoominButton;
	}

	private TextButton getLayersButton() {
		if (layersButton == null) {
			layersButton = new TextButton();
			layersButton.setToolTip("New&nbsp;Layer");
			layersButton.setIcon(Images.getImageResources().layers_34());
			layersButton.addSelectHandler(getLayersHandler());
		}
		return layersButton;
	}

	private TextButton getNewFlyerButton() {
		if (btnNewFlyer == null) {
			btnNewFlyer = new TextButton();
			btnNewFlyer.setToolTip("New&nbsp;Flyer");
			btnNewFlyer.setIcon(Images.getImageResources().f5_blue_32());
			btnNewFlyer.addSelectHandler(getNewFlyerHandler());
		}
		return btnNewFlyer;
	}

	private TextButton getNewVideoButton() {
		if (btnNewVideo == null) {
			btnNewVideo = new TextButton();
			btnNewVideo.setToolTip("New&nbsp;Video");
			btnNewVideo.setIcon(Images.getImageResources().video_34());
			btnNewVideo.addSelectHandler(getNewVideoHandler());
		}
		return btnNewVideo;
	}

	private TextButton getPlayButton() {
		if (btnPlay == null) {
			btnPlay = new TextButton();
			btnPlay.setToolTip("Play");
			btnPlay.setIcon(Images.getImageResources().play_32());
			btnPlay.addSelectHandler(getPlayHandler());
		}
		return btnPlay;
	}

	private TextButton getFolderButton() {
		if (btnFolder == null) {
			btnFolder = new TextButton();
			btnFolder.setToolTip("New Folder");
			btnFolder.setIcon(Images.getImageResources().folder_32());
			btnFolder.addSelectHandler(getFolderHandler());
		}
		return btnFolder;
	}

	private SelectHandler getZoominHandler() {
		if (zoominHandler == null) {
			zoominHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new ZoomInMsg());
				}
			};
		}
		return zoominHandler;
    }

	private SelectHandler getPlayHandler() {
		if (playHandler == null) {
			playHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new PlayMsg());
				}
			};
		}
		return playHandler;
    }

	private SelectHandler getFolderHandler() {
		if (folderHandler == null) {
			folderHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewFolderMsg());
				}
			};
		}
		return folderHandler;
    }

	private SelectHandler getLayersHandler() {
		if (layersHandler == null) {
			layersHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewLayerMsg());
				}
			};
		}
		return layersHandler;
    }

	private SelectHandler getNewFlyerHandler() {
		if (newFlyerHandler == null) {
			newFlyerHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewFlyerMsg());
				}
			};
		}
		return newFlyerHandler;
    }

	private SelectHandler getNewVideoHandler() {
		if (newVideoHandler == null) {
			newVideoHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewVideoMsg());
				}
			};
		}
		return newVideoHandler;
    }

	private SelectHandler getZoomoutHandler() {
		if (zoomoutHandler == null) {
			zoomoutHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new ZoomOutMsg());
				}
			};
		}
		return zoomoutHandler;
    }

	private SelectHandler getNewPolygonHandler() {
		if (newPolygonHandler == null) {
			newPolygonHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(Fpolygon.class));
				}
			};
		}
		return newPolygonHandler;
    }

	private SelectHandler getNewRegularPolygonHandler() {
		if (newRegularPolygonHandler == null) {
			newRegularPolygonHandler = new SelectHandler() {
				@Override
				public void onSelect(SelectEvent event) {
					FlyerContext.getMb().sendMsg(new NewNodeMsg(FregularPolygon.class));
				}
			};
		}
		return newRegularPolygonHandler;
    }

	private TextButton getZoomoutButton() {
		if (zoomoutButton == null) {
			zoomoutButton = new TextButton();
			zoomoutButton.setToolTip("Zoom&nbsp;Out");
			zoomoutButton.setIcon(Images.getImageResources().zoomout_32());
			zoomoutButton.addSelectHandler(getZoomoutHandler());
		}
		return zoomoutButton;
	}

	private TextButton getNewPolygonButton() {
		if (btnNewPolygon == null) {
			btnNewPolygon = new TextButton();
			btnNewPolygon.setToolTip("New&nbsp;Polygon");
			btnNewPolygon.setIcon(Images.getImageResources().polygon3_32());
			btnNewPolygon.addSelectHandler(getNewPolygonHandler());
		}
		return btnNewPolygon;
	}

	private TextButton getNewRegularPolygonButton() {
		if (btnNewRegularPolygon == null) {
			btnNewRegularPolygon = new TextButton();
			btnNewRegularPolygon.setToolTip("New&nbsp;Regular&nbsp;Polygon");
			btnNewRegularPolygon.setIcon(Images.getImageResources().polygon3_32());
			btnNewRegularPolygon.addSelectHandler(getNewRegularPolygonHandler());
		}
		return btnNewRegularPolygon;
	}

	private Widget getToolBar() {
		if (toolBar == null) {
			toolBar = new ToolBar();
			toolBar.setBorders(false);
			
			toolBar.add(createHomeButton());
			toolBar.add(getFolderButton());
			toolBar.add(getNewFlyerButton());
			toolBar.add(getLayersButton());
			toolBar.add(getNewLineButton());
			toolBar.add(getNewTextButton());
			toolBar.add(getNewImageButton());
			toolBar.add(getNewCircleButton());
			toolBar.add(getNewRectButton());
			toolBar.add(getNewEllipseButton());
			toolBar.add(getNewRegularPolygonButton());
			toolBar.add(getNewVideoButton());
			
			toolBar.add(new SeparatorToolItem());
			toolBar.add(getZoominButton());
			toolBar.add(getZoomoutButton());
			
			toolBar.add(new SeparatorToolItem());
			toolBar.add(getRemoveSelectedButton());
			toolBar.add(createCopyButton());
			toolBar.add(createPasteButton());
			toolBar.add(getPlayButton());
		}
		return toolBar;
	}

	private TextButton createButton(String tip, ImageResource img, SelectHandler handler) {
		TextButton btn = new TextButton();
		btn.setToolTip(tip);
		btn.setIcon(img);
		btn.addSelectHandler(handler);
		return btn;
	}
	
	private TextButton createCopyButton() {
		return createButton("copy", Images.getImageResources().copy_32(), new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				FlyerContext.getMb().sendMsg(new CopyMsg());
			}
		});
	}
	
	private TextButton createPasteButton() {
		return createButton("paste", Images.getImageResources().paste_32(), new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				FlyerContext.getMb().sendMsg(new PasteMsg());
			}
		});
	}
	
	private TextButton createHomeButton() {
		return createButton("Home", Images.getImageResources().home_32(), new SelectHandler() {
			@Override
			public void onSelect(SelectEvent event) {
				Window.Location.assign("index.php");
			}
		});
	}
}
