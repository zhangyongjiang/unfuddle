/**
 * Sencha GXT 3.0.1 - Sencha for GWT
 * Copyright(c) 2007-2012, Sencha, Inc.
 * licensing@sencha.com
 *
 * http://www.sencha.com/products/gxt/license/
 */
package com.sencha.gxt.desktopapp.client.property;

import com.google.gwt.resources.client.ImageResource;
import com.sencha.gxt.data.shared.IconProvider;
import com.sencha.gxt.desktopapp.client.filemanager.images.Images;
import com.sencha.gxt.desktopapp.client.persistence.FileModel;
import com.sencha.gxt.desktopapp.client.persistence.FileModel.FileType;

public class PropertyIconProvider implements IconProvider<FileModel> {

  @Override
  public ImageResource getIcon(FileModel fileModel) {
    ImageResource icon = null;
    FileType fileType = fileModel.getFileType();
    switch (fileType) {
      case BOOKMARK:
        icon = Images.getImageResources().world();
        break;
      case DOCUMENT:
        icon = Images.getImageResources().page_white();
        break;
      case FOLDER:
        icon = Images.getImageResources().folder();
        break;
      case PROGRAM:
        icon = Images.getImageResources().script();
        break;
      case SPREADSHEET:
        icon = Images.getImageResources().table();
        break;
    }
    return icon;
  }
}
