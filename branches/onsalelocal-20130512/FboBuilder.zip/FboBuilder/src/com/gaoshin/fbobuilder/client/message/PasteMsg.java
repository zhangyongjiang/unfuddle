package com.gaoshin.fbobuilder.client.message;


public class PasteMsg extends Message {

}
