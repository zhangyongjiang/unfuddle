package com.gaoshin.fbobuilder.client.editor;

import net.edzard.kinetic.Rectangle;

import com.gaoshin.fbobuilder.client.model.Frectangle;

public class RectangleEditor extends ShapeEditor {
	private Frectangle frectangle;
	private Rectangle rectangle;
}
