package com.gaoshin.fbobuilder.client.message;


public class NewFlyerMsg extends Message {

}
