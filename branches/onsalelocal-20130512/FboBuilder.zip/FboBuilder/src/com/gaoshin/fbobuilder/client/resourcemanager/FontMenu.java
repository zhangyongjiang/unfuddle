package com.gaoshin.fbobuilder.client.resourcemanager;

import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.sencha.gxt.widget.core.client.menu.Item;
import com.sencha.gxt.widget.core.client.menu.Menu;
import com.sencha.gxt.widget.core.client.menu.MenuItem;

public class FontMenu extends Menu {
	public static final String[] fontFamilies = {
		"Arial,sans-serif",
		"'Arial Black',Gadget,sans-serif",
		"'Comic Sans MS',cursive",
		"'Monotype Sorts',dingbats,'ITC Zapf Dingbats',fantasy",
		"Tahoma,sans-serif",
		"Bonbon",
		"Cambria,'Times New Roman','Nimbus Roman No9 L','Freeserif',Times,serif",
		"Clicker Script",
		"Codystar",
		"Consolas,'Lucida Console','DejaVu Sans Mono',monospace",
		"Constantia,Georgia,'Nimbus Roman No9 L',serif",
		"Ewert",
		"Freckle Face",
		"Grand Hotel",
		"Hanalei",
		"Herr Von Muellerhoff",
		"Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif",
		"Merienda",
		"Monoton",
		"Mrs Saint Delafield",
		"Mystery Quest",
		"New Rocker",
		"Princess Sofia",
		"Qwigley",
		"Ribeye Marrow",
		"Sacramento",
		"Seymour One",
		"Sofia",
		"Sonsie One",
		"Tangerine",
		"Webdings,fantasy",
		"Wingdings,fantasy",
    };
	
	public static interface FontSelectedListener {
		void onFontSelected(String fontFamily);
	}

	private FontSelectedListener listener;
	
	public FontMenu() {
		for (String family : fontFamilies) {
			MenuItem item = new MenuItem(family);
			item.addSelectionHandler(new SelectionHandler<Item>() {
				@Override
				public void onSelection(SelectionEvent<Item> event) {
					String fontFamily = ((MenuItem)event.getSelectedItem()).getText();
					if(listener != null)
						listener.onFontSelected(fontFamily);
				}
			});
			add(item);
		}
	}
	
	public void setListener(FontSelectedListener listener) {
		this.listener = listener;
	}
}
