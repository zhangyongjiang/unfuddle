package com.gaoshin.fbobuilder.client.editor;

public class ShapeEditor extends NodeEditor {

}
