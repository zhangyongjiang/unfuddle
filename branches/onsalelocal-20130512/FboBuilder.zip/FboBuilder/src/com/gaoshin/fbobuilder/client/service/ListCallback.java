package com.gaoshin.fbobuilder.client.service;

import com.gaoshin.fbobuilder.client.resourcemanager.FlyerFolderProperty;

public interface ListCallback {
	void list(String dir, FlyerFolderProperty ffp);
}
