package com.gaoshin.fbobuilder.client.message;


public class NewNodeMsg extends Message {
	private Class nodeCls;
	
	public NewNodeMsg(Class nodeCls) {
		this.nodeCls = nodeCls;
    }

	public Class getNodeCls() {
	    return nodeCls;
    }

	public void setNodeCls(Class nodeCls) {
	    this.nodeCls = nodeCls;
    }

}
