package com.gaoshin.fbobuilder.client.editor;

public class Zindex {
	public static final int TOP = 999999;
}
