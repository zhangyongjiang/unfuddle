package com.gaoshin.fbobuilder.client.message;

public class UnshareMsg extends Message {

}
