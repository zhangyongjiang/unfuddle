package com.gaoshin.fbobuilder.client.message;

public class PostToFbMsg extends Message {

}
