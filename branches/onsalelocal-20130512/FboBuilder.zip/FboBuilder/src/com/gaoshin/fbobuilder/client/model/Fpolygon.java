package com.gaoshin.fbobuilder.client.model;

import java.util.ArrayList;
import java.util.List;

import net.edzard.kinetic.Kinetic;
import net.edzard.kinetic.Polygon;
import net.edzard.kinetic.Vector2d;

import com.gaoshin.fbobuilder.client.model.Controller.ControllerAnchor;
import com.gaoshin.fbobuilder.client.resourcemanager.PolygonProperty;

public class Fpolygon extends Fshape<Polygon, PolygonProperty> {

	public Fpolygon(Flayer flayer, PolygonProperty pp) {
	    super(flayer, pp);
    }

	@Override
    public List<MarkedPosition> getAnchors() {
		Vector2d pos = node.getPosition();
		List<MarkedPosition> anchors = new ArrayList<MarkedPosition>();
		List<Vector2d> points = node.getPoints();
		for(int i=0; i<points.size(); i++) {
			Vector2d v = points.get(i);
			v.x += pos.x;
			v.y += pos.y;
			anchors.add(new MarkedPosition(node.getPosition(), i, v));
		}
		return anchors;
    }

	@Override
    public Polygon createKineticNode() {
		Vector2d size = getStage().getSize();
	    Vector2d scale = getStage().getScale();
	    Vector2d first = new Vector2d();
		Vector2d second = new Vector2d();
		Vector2d third = new Vector2d();
	    first.x = size.x / 2 / scale.x;
	    first.y = size.y / 4 / scale.y;
	    second.x = size.x / 4 / scale.x;
	    second.y = size.y / 4 / scale.y;
	    third.x = size.x * 3 / 4 / scale.x;
	    third.y = size.y * 3 / 4 / scale.y;
		return Kinetic.createPolygon(first, second, third);
    }

	public boolean onAnchorDragMove(ControllerAnchor anchor, Vector2d newPos) {
		MarkedPosition pos = anchor.mp;
		Vector2d nodpos = node.getPosition();
		int index = (Integer) pos.getId();
		List<Vector2d> points = node.getPoints();
		for(int i=0; i<points.size(); i++) {
			Vector2d v = points.get(i);
			if(i == index) {
				v.x = newPos.x + nodpos.x;
				v.y = newPos.y + nodpos.y;
			}
			else {
				v.x += nodpos.x;
				v.y += nodpos.y;
			}
			node.setPoint(i, v);
		}
		
		node.setPosition(0, 0);
		return false;
	}

	@Override
    public PolygonProperty createResourceProperty() {
	    return null;
    }
}
