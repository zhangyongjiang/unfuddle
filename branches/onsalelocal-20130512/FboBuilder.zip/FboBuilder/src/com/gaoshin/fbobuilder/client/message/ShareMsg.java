package com.gaoshin.fbobuilder.client.message;

public class ShareMsg extends Message {

}
