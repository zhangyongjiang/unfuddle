package com.gaoshin.fbobuilder.client.resourcemanager;

public class StringProperty extends PrimeProperty<String> {
	@Override
	public void setStringValue(String value) {
		setValue(value);
	}
}
