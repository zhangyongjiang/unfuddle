package com.gaoshin.fbobuilder.client.message;


public class RefreshMsg extends Message {

}
