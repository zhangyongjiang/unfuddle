package com.gaoshin.fbobuilder.client.editor;

public class StarEditor extends ShapeEditor {

}
