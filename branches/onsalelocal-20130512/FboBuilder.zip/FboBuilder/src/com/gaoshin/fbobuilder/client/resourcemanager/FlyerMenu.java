package com.gaoshin.fbobuilder.client.resourcemanager;

import com.gaoshin.fbobuilder.client.FlyerContext;
import com.gaoshin.fbobuilder.client.message.RemoveMsg;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.sencha.gxt.examples.resources.client.images.ExampleImages;
import com.sencha.gxt.widget.core.client.menu.Item;
import com.sencha.gxt.widget.core.client.menu.Menu;
import com.sencha.gxt.widget.core.client.menu.MenuItem;

public class FlyerMenu extends Menu {
	private MenuItem remove;

	public FlyerMenu() {
		remove = new MenuItem();
		remove.setEnabled(true);
		remove.setText("Remove");
		remove.setIcon(ExampleImages.INSTANCE.delete());
		remove.addSelectionHandler(new SelectionHandler<Item>() {
			@Override
			public void onSelection(SelectionEvent<Item> event) {
				FlyerContext.getMb().sendMsg(new RemoveMsg());
			}
		});
		add(remove);

    }
}
