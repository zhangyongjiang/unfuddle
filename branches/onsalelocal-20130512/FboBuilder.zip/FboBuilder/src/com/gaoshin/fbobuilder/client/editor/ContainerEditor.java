package com.gaoshin.fbobuilder.client.editor;

public class ContainerEditor extends NodeEditor {

}
