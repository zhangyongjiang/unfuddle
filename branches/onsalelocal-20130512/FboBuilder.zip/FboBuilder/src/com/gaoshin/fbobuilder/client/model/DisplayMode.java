package com.gaoshin.fbobuilder.client.model;

public enum DisplayMode {
	Edit,
	ViewOnly
}
