package com.gaoshin.fbobuilder.client.message;


public class UpMsg extends Message {

}
