package com.gaoshin.fbobuilder.client.resourcemanager;

public interface ResourceTree {
	ResourceProperty getTree();
}
