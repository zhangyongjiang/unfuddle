package com.gaoshin.fbobuilder.client.resourcemanager;

public class InvalidValueException extends RuntimeException {

}
