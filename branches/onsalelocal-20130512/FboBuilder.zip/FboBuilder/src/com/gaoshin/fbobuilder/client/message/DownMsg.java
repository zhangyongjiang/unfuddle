package com.gaoshin.fbobuilder.client.message;


public class DownMsg extends Message {

}
