package com.gaoshin.fbobuilder.client.editor;

public class PolygonEditor extends ShapeEditor {

}
