package com.gaoshin.fbobuilder.client.resourcemanager;

public class FilePropertyMenu extends FlyerMenu {

}
