package com.gaoshin.fbobuilder.client.model;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

public interface EditorImages extends ClientBundle {
	public EditorImages INSTANCE = GWT.create(EditorImages.class);

	ImageResource beach_256();
	ImageResource rotation_57x36();
	ImageResource rotation_36x57();
}
