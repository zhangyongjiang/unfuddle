package com.gaoshin.fbobuilder.client.resourcemanager;

public class AudioProperty extends FileProperty {
	public AudioProperty() {
		setType(PropertyType.Audio);
    }
}
