package com.gaoshin.fbobuilder.client.resourcemanager;

import com.gaoshin.fbobuilder.client.model.Fpolygon;

public class PolygonProperty extends ShapeProperty<Fpolygon> {
	
	public PolygonProperty() {
		setType(PropertyType.Polygon);
    }
	
	@Override
	public void fromFnode(Fpolygon fshape) {
	    super.fromFnode(fshape);
	}
}
