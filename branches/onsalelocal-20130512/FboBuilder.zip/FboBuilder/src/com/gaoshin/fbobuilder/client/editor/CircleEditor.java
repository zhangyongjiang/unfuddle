package com.gaoshin.fbobuilder.client.editor;

public class CircleEditor extends ShapeEditor {
}
