package com.gaoshin.fbobuilder.client.model;

import net.edzard.kinetic.Circle;

public class Anchor {
		private Circle circle;
		private MarkedPosition mp;

}
