package com.gaoshin.fbobuilder.client.resourcemanager;

public class FontFamilyProperty extends StringProperty {

}
