package com.gaoshin.fbobuilder.client.editor;

public class GroupEditor extends ContainerEditor {

}
