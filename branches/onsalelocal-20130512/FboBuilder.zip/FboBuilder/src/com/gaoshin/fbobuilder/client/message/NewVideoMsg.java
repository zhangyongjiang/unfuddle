package com.gaoshin.fbobuilder.client.message;


public class NewVideoMsg extends Message {

}
