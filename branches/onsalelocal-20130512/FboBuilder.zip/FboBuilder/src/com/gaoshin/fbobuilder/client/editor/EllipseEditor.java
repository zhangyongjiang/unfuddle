package com.gaoshin.fbobuilder.client.editor;

public class EllipseEditor extends ShapeEditor {

}
