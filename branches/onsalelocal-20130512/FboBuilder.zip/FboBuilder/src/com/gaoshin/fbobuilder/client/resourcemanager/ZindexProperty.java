package com.gaoshin.fbobuilder.client.resourcemanager;

public class ZindexProperty extends IntProperty {
	public ZindexProperty() {
		setModifiable(false);
    }
}
